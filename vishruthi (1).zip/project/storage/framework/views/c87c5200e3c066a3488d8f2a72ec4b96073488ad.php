<?php $__env->startSection('content'); ?>    
	<!--slider area start-->
    <?php if($ps->slider == 1): ?>

	<div class="slider_area slider_style owl-carousel">
		<?php if(count($sliders)): ?>
		<?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
		<div class="single_slider" data-bgimg="<?php echo e(asset('assets/images/sliders/'.$data->photo)); ?>">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-12">
                        <div class="slider_content content_one">
                            <!-- <img src="<?php echo e(asset('assets/front/vishruthi/img/slider/content.png')); ?>" alt=""> -->
                            <p><?php echo e($data->details_text); ?></p>
                            <a href="<?php echo e($data->link); ?>">Discover Now</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
    </div>
	<?php endif; ?>
    <!--slider area end-->
	<section id="extraData">
	
	</section>
    <!--Instagram area start-->
    <section class="instagram_area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="section_title">
                        <h2>Follow us On Instagram</h2>
                        <p>Stay connected with #vishruthijewelemporium</p>
                    </div>
                </div>
            </div>
            <div class="instagram_home_block">
                <div class="row">
                    <div class="instagram_wrapper instagram_column5 owl-carousel">
						<?php
						$feed = 8;
						$timestamp = mktime(date('H'), date('i'), 0, date('n'), date('j') - 1, date('Y'));
						$AccessToken = 'IGQVJWSlF0eHJXSUdPTk9aYzA3NWlSWGxBS1FXb2gtNTlJNHl5cjVhRDRhVU56RllRdlFJTFhteTFoclJBT19MbFRLZAzV3bHRJVzBmLWxzSXdsNy1neVkxamxFX3p0SGFGdWZAWRHdPNVNzRUNzOS1zdgZDZD';
						$instagram_user_id = '4992666810766440';
						$url = 'https://graph.instagram.com/'.$instagram_user_id.'/media?access_token=' . $AccessToken;
						$counter = 0;						
						$ch = curl_init();
						curl_setopt($ch, CURLOPT_URL, $url);
						curl_setopt($ch, CURLOPT_HEADER, false);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
						curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
						curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
						curl_setopt($ch, CURLOPT_USERAGENT, 'Instagram Gallery');
						$result = curl_exec($ch);
						$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
						curl_close($ch);
						$result = json_decode($result);
						foreach ($result->data as $media_id){
							$id = $media_id->id;
							$counter++;
							if( $counter <= $feed ){
								if( $id ) {
									$url = 'https://graph.instagram.com/'.$id.'?fields=id,media_type,media_url,username,timestamp,permalink&access_token=' . $AccessToken;
									$ch = curl_init();
									curl_setopt($ch, CURLOPT_URL, $url);
									curl_setopt($ch, CURLOPT_HEADER, false);
									curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
									curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
									curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
									curl_setopt($ch, CURLOPT_USERAGENT, 'Instagram Gallery');
									$result_image = curl_exec($ch);
									curl_close($ch);
									$result_image = json_decode($result_image); ?>
									<div class="col-lg-3">
										<div class="single_instagram">
											<a href="javascript:;"><img src="<?php echo $result_image->media_url; ?>" alt=""></a>
											<div class="instagram_icone">
												<a class="instagram_pupop" href="<?php echo $result_image->media_url; ?>"><i class="fa fa-instagram"></i></a>
											</div>
										</div>
									</div>
									<?php
								}
							}
						}	?>
						<!--<div class="col-lg-3">
                            <div class="single_instagram">
                                <a href="#"><img src="<?php echo e(asset('assets/front/vishruthi/img/about/intagram.png')); ?>" alt=""></a>
                                <div class="instagram_icone">
                                    <a class="instagram_pupop" href="<?php echo e(asset('assets/front/vishruthi/img/about/intagram.png')); ?>"><i class="fa fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="single_instagram">
                                <a href="#"><img src="<?php echo e(asset('assets/front/vishruthi/img/about/intagram1.png')); ?>" alt=""></a>
                                <div class="instagram_icone">
                                    <a class="instagram_pupop" href="<?php echo e(asset('assets/front/vishruthi/img/about/intagram1.png')); ?>"><i class="fa fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="single_instagram">
                                <a href="#"><img src="<?php echo e(asset('assets/front/vishruthi/img/about/intagram2.png')); ?>" alt=""></a>
                                <div class="instagram_icone">
                                    <a class="instagram_pupop" href="<?php echo e(asset('assets/front/vishruthi/img/about/intagram2.png')); ?>"><i class="fa fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="single_instagram">
                                <a href="#"><img src="<?php echo e(asset('assets/front/vishruthi/img/about/intagram3(1).png')); ?>" alt=""></a>
                                <div class="instagram_icone">
                                    <a class="instagram_pupop" href="<?php echo e(asset('assets/front/vishruthi/img/about/intagram3(1).png')); ?>"><i class="fa fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="single_instagram">
                                <a href="#"><img src="<?php echo e(asset('assets/front/vishruthi/img/about/intagram4(1).png')); ?>" alt=""></a>
                                <div class="instagram_icone">
                                    <a class="instagram_pupop" href="<?php echo e(asset('assets/front/vishruthi/img/about/intagram4(1).png')); ?>"><i class="fa fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="single_instagram">
                                <a href="#"><img src="<?php echo e(asset('assets/front/vishruthi/img/about/intagram1.png')); ?>" alt=""></a>
                                <div class="instagram_icone">
                                    <a class="instagram_pupop" href="<?php echo e(asset('assets/front/vishruthi/img/about/intagram1.png')); ?>"><i class="fa fa-instagram"></i></a>
                                </div>
                            </div>
                        </div> -->
                    </div>
                    <div class="col-12">
                        <div class="text_follow">
                            <a href="<?php echo e($socialsetting->linkedin); ?>" target="_blank">#Follow us on Instagram</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Instagram area end-->	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
	<script>
        $(window).on('load',function() {

            setTimeout(function(){

                $('#extraData').load('<?php echo e(route('front.extraIndex')); ?>');

            }, 500);
        });

	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.vishruthi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vishruthijewelem/public_html/project/resources/views/front/index.blade.php ENDPATH**/ ?>