
<?php $__env->startSection('content'); ?>
        <!--breadcrumbs area start-->
        <div class="breadcrumbs_area other_bread">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb_content">
                            <ul>
                                <li><a href="<?php echo e(route('front.index')); ?>">home</a></li>
                                <li>/</li>
                                <li>Orders</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--breadcrumbs area end-->

        <!-- my account start  -->
        <section class="main_content_area">
            <div class="container">
                <div class="account_dashboard">
                    <div class="row">
						<?php echo $__env->make('includes.user-dashboard-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="col-sm-12 col-md-9 col-lg-9">
                            <!-- Tab panes -->
                            <div class="tab-content dashboard_content">
                                <div class="tab-pane fade show active" id="orders">
                                    <h3>Orders</h3>
									<div class="table-responsiv">
										<table id="example" class="table table-hover dt-responsive" cellspacing="0" width="100%">
											<thead>
												<tr>
													<th><?php echo e($langg->lang278); ?></th>
													<th><?php echo e($langg->lang279); ?></th>
													<th><?php echo e($langg->lang280); ?></th>
													<th><?php echo e($langg->lang281); ?></th>
													<th><?php echo e($langg->lang282); ?></th>
												</tr>
											</thead>
											<tbody>
												 <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<tr>
													<td>
															<?php echo e($order->order_number); ?>

													</td>
													<td>
															<?php echo e(date('d M Y',strtotime($order->created_at))); ?>

													</td>
													<td>
															<?php echo e($order->currency_sign); ?><?php echo e(round($order->pay_amount * $order->currency_value , 2)); ?>

													</td>
													<td>
														<div class="order-status <?php echo e($order->status); ?>">
																<?php echo e(ucwords($order->status)); ?>

														</div>
													</td>
													<td>
														<a class="mybtn2 sm" href="<?php echo e(route('user-order',$order->id)); ?>">
																<?php echo e($langg->lang283); ?>

														</a>
													</td>
												</tr>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</tbody>
										</table>
									</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- my account end   -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript">
		$('#example').DataTable({
			"paging":   true,
			"ordering": true,
			"info":     true
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.vishruthi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vishruthijewelem/public_html/project/resources/views/user/order/index.blade.php ENDPATH**/ ?>