<?php if(count($prods) > 0): ?>
	<?php $__currentLoopData = $prods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="col-lg-4 col-md-4 col-12">
		<div class="single_product">
			<div class="product_thumb">
				<a class="primary_img" href="<?php echo e(route('front.product', $prod->slug)); ?>"><img src="<?php echo e(filter_var($prod->photo, FILTER_VALIDATE_URL) ?$prod->photo:asset('assets/images/products/'.$prod->photo)); ?>" alt="" /></a>
				<!--<a class="secondary_img" href="product-details.html"><img src="<?php echo e(asset('assets/front/vishruthi/img/product/product23.jpg')); ?>" alt="" /></a>-->
				<div class="product_action">
					<div class="hover_action">
						<a href="#"><i class="fa fa-plus"></i></a>
						<div class="action_button">
							<ul>
								<!--<li>
									<a title="add to cart" href="cart.html"><i class="fa fa-shopping-basket" aria-hidden="true"></i></a>
								</li>-->
								<?php if(Auth::guard('web')->check()): ?>								<li>									<a  href="javascript:;"  title="Add to Wishlist" class="add-to-wish" data-href="<?php echo e(route('user-wishlist-add',$prod->id)); ?>"><i class="fa fa-heart-o" aria-hidden="true"></i></a>								</li>								<?php else: ?>								<li>									<a  href="<?php echo e(route('user.login')); ?>"  title="Add to Wishlist" class="add-to-wis" ><i class="fa fa-heart-o" aria-hidden="true"></i></a>								</li>								
								<?php endif; ?>
								<li style="display:none;">
									<a href="compare.html" title="Add to Compare"><i class="fa fa-sliders" aria-hidden="true"></i></a>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="quick_button">
					<a href="javascript:;" data-toggle="modal" data-target="#quickview" data-href="<?php echo e(route('product.quick',$prod->id)); ?>" title="quick_view" class="quick-view">+ quick view</a>
				</div>
				<?php					$date1 = new DateTime($prod->created_at);					$date2 = new DateTime(date("Y-m-d H:i:s"));					$difference = $date1->diff($date2);					if (($difference->y == 0) && ($difference->m == 0) && ($difference->d < 10)){						echo '<div class="label_product"><span>new</span></div>';					}				?>
			</div>

			<div class="product_content grid_content">
				<h3><a href="product-details.html"><?php echo e($prod->showName()); ?></a></h3>
				<span class="current_price"><?php echo e($prod->setCurrency()); ?></span>
			</div>

			<div class="product_content list_content">
				<h3><a href="<?php echo e(route('front.product', $prod->slug)); ?>"><?php echo e($prod->showName()); ?></a></h3>
				<div class="product_ratting">
					<ul>
						<li>
							<a href="#"><i class="fa fa-star"></i></a>
						</li>
						<li>
							<a href="#"><i class="fa fa-star"></i></a>
						</li>
						<li>
							<a href="#"><i class="fa fa-star"></i></a>
						</li>
						<li>
							<a href="#"><i class="fa fa-star"></i></a>
						</li>
						<li>
							<a href="#"><i class="fa fa-star"></i></a>
						</li>
					</ul>
				</div>
				<div class="product_price">
					<span class="current_price"><?php echo e($prod->setCurrency()); ?></span>
					<span class="old_price"><?php echo e($prod->showPreviousPrice()); ?></span>
				</div>
				<div class="product_desc">
					<p>
						<?php echo e(mb_substr(strip_tags($prod->details), 0, 236,"UTF-8")); ?>

					</p>
				</div>
			</div>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<div class="col-lg-12 shop_toolbar t_bottom">
		<div class="page-center">
			<?php echo $prods->appends(['search' => request()->input('search')])->links(); ?>

		</div>
	</div>
	<div class="shop_toolbar t_bottom" style="display:none;">
		<div class="pagination">
			<ul>
				<li class="current">1</li>
				<li><a href="#">2</a></li>
				<li><a href="#">3</a></li>
				<li class="next"><a href="#">next</a></li>
				<li><a href="#">>></a></li>
			</ul>
		</div>
	</div>
<?php else: ?>
	<div class="col-lg-12">
		<div class="page-center">
			 <h4 class="text-center"><?php echo e($langg->lang60); ?></h4>
		</div>
	</div>
<?php endif; ?>	<?php /**PATH /home/vishruthijewelem/public_html/project/resources/views/includes/product/filtered-products.blade.php ENDPATH**/ ?>