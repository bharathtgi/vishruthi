                        <?php if(isset($order)): ?>
                    <div class="tracking-steps-area">
							<p>Payment Status : <?php echo e($order->payment_status); ?> </p>
							<p>Delivery Status : <?php echo e(ucfirst($order->status)); ?></p>
                            <ul class="tracking-steps">
                                <?php $__currentLoopData = $order->tracks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $track): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="<?php echo e(in_array($track->title, $datas) ? 'active' : ''); ?>">
                                        <div class="icon"><?php echo e($loop->index + 1); ?></div>
                                        <div class="content">
                                                <h4 class="title"><?php echo e(ucwords($track->title)); ?> (<?php echo e(date('d M, Y',strtotime($track->created_at))); ?>)</h4>
                                                <p class="details"><?php echo e($track->text); ?></p>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>
                    </div>


                        <?php else: ?> 
                        <h3 class="text-center"><?php echo e($langg->lang775); ?></h3>
                        <?php endif; ?>          <?php /**PATH /home/vishruthijewelem/public_html/project/resources/views/load/track-load.blade.php ENDPATH**/ ?>