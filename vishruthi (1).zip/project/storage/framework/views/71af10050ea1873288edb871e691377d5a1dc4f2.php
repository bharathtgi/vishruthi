<?php $__env->startSection('content'); ?>
        <!--breadcrumbs area start-->
        <div class="breadcrumbs_area other_bread">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb_content">
                            <ul>
                                <li><a href="<?php echo e(route('front.index')); ?>">home</a></li>
                                <li>/</li>
                                <li>cart</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--breadcrumbs area end-->

        <!--shopping cart area start -->
        <div class="shopping_cart_area">
            <div class="container">
                
                    <div class="row">
                        <div class="col-12">
                            <div class="table_desc">
                                <div class="cart_page table-responsive">
                                    <?php if(Session::has('cart')): ?>
									<table>
                                        <thead>
                                            <tr>
                                                <th class="product_remove">Delete</th>
                                                <th class="product_thumb">Image</th>
                                                <th class="product_name">Product</th>
                                                <th class="product-price">Price</th>
                                                <th class="product_quantity">Quantity</th>
                                                <th class="product_total">Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>
											
												<?php
													$discount = 0;
												?>												
												<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													
														<?php if(isset($product['discount1'])): ?>															$discount += $product['discount1'];														<?php endif; ?>
																											<?php
														$temp_item_id = str_replace(".","dot",$product['item']['id'].$product['size'].$product['color'].$product['chaintype'].$product['banglesize'].str_replace(str_split(' ,'),'',$product['values']));													?>											
													<tr class="cremove<?php echo e($temp_item_id); ?>" >
														<td class="product_remove">
															<a href="javascript:;" class="removecart cart-remove" data-class="cremove<?php echo e($temp_item_id); ?>" data-href="<?php echo e(route('product.cart.remove',$product['item']['id'].$product['size'].$product['color'].$product['chaintype'].$product['banglesize'].str_replace(str_split(' ,'),'',$product['values']))); ?>"><i class="fa fa-trash-o"></i></a>
														</td>
														<td class="product_thumb">
															<a href="<?php echo e(route('front.product', $product['item']['slug'])); ?>"><img src="<?php echo e($product['item']['photo'] ? asset('assets/images/products/'.$product['item']['photo']):asset('assets/images/noimage.png')); ?>" alt="" style="width:100px;" /></a>
														</td>
														<td class="product_name">
															<a href="<?php echo e(route('front.product', $product['item']['slug'])); ?>"><?php echo e(mb_strlen($product['item']['name'],'utf-8') > 35 ? mb_substr($product['item']['name'],0,35,'utf-8').'...' : $product['item']['name']); ?></a>
															<?php if(!empty($product['chaintype'])): ?>
																<br/><b>Chain Type</b> : <?php echo e($product['chaintype']); ?>

															<?php endif; ?>
															<?php if(!empty($product['banglesize'])): ?>
																<br/><b>Bangle Size</b> : <?php echo e($product['banglesize']); ?>

															<?php endif; ?>															
														</td>
														<td class="product-price"><?php echo e(App\Models\Product::convertPrice($product['item_price'])); ?></td>
														<td class="product_quantity">
															<div class="qty">
																<ul>
																	<input type="hidden" class="prodid" value="<?php echo e($product['item']['id']); ?>">  
																	<input type="hidden" class="itemid" value="<?php echo e($product['item']['id'].$product['size'].$product['color'].$product['chaintype'].$product['banglesize'].str_replace(str_split(' ,'),'',$product['values'])); ?>">
																	<input type="hidden" class="tempitemid" value="<?php echo e($temp_item_id); ?>">																	
																	<input type="hidden" class="size_qty" value="<?php echo e($product['size_qty']); ?>">     
																	<input type="hidden" class="size_price" value="<?php echo e($product['size_price']); ?>">   
																	<li><span class="qtminus1 reducing" style="cursor: pointer;"><i class="fa fa-minus"></i></span></li>
																	<li><span class="qttotal1" id="qty<?php echo e($temp_item_id); ?>"><?php echo e($product['qty']); ?></span></li>
																	<li><span class="qtplus1 adding" style="cursor: pointer;"><i class="fa fa-plus"></i></span></li>
																</ul>
															</div>
														</td>
														<?php if($product['size_qty']): ?>
														<input type="hidden" id="stock<?php echo e($product['item']['id'].$product['size'].$product['color'].$product['chaintype'].$product['banglesize'].str_replace(str_split(' ,'),'',$product['values'])); ?>" value="<?php echo e($product['size_qty']); ?>">
														<?php elseif($product['item']['type'] != 'Physical'): ?> 
														<input type="hidden" id="stock<?php echo e($product['item']['id'].$product['size'].$product['color'].$product['chaintype'].$product['banglesize'].str_replace(str_split(' ,'),'',$product['values'])); ?>" value="1">
														<?php else: ?>
														<input type="hidden" id="stock<?php echo e($product['item']['id'].$product['size'].$product['color'].$product['chaintype'].$product['banglesize'].str_replace(str_split(' ,'),'',$product['values'])); ?>" value="<?php echo e($product['stock']); ?>">
														<?php endif; ?>														
														<td class="product_total total-price">                              
															<p id="prc<?php echo e($temp_item_id); ?>">
																<?php echo e(App\Models\Product::convertPrice($product['price'])); ?>                 
															</p>
														</td>
													</tr>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											
										</tbody>
                                    </table>
									<?php else: ?>
									Cart Empty
									<?php endif; ?>
                                </div>
                                <!--<div class="cart_submit">
                                    <button type="submit">update cart</button>
                                </div>-->
                            </div>
                        </div>
                    </div>

                    <!--coupon code area start-->
                    <?php if(Session::has('cart')): ?>
					<div class="coupon_area">
                        <div class="row">
                            <div class="col-lg-6 col-md-6">
                                <div class="coupon_code left">
                                    <h3>Coupon</h3>
                                    <div class="coupon_inner">
                                        <p>Enter your coupon code if you have one.</p>
                                        <form id="coupon-form" class="coupon" >
											<input type="text" placeholder="<?php echo e($langg->lang133); ?>" id="code" required="" autocomplete="off">
											<input type="hidden" class="coupon-total" id="grandtotal" value="<?php echo e(Session::has('cart') ? App\Models\Product::convertPrice($mainTotal) : '0.00'); ?>">
											<button type="submit">Apply coupon</button>
										</form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6">
                                <div class="coupon_code right">
                                    <h3>Cart Totals</h3>
                                    <div class="coupon_inner">
                                        <div class="cart_subtotal">
                                            <p>Subtotal</p>
                                            <p class="cart-total"><?php echo e(Session::has('cart') ? App\Models\Product::convertPrice($totalPrice+ $discount) : '0.00'); ?></p>
                                        </div>
										<?php if($tax_amount != 0): ?>
                                        <div class="cart_subtotal">
                                            <p>Tax(<?php echo e($tx); ?>%)</p>
											<p class="tax-amt"><?php echo e(App\Models\Product::convertPrice($tax_amount)); ?></p>
                                        </div>	
										<?php endif; ?>
                                        <div class="cart_subtotal">
                                            <p>Discount</p>
											<p class="discount"><?php echo e(App\Models\Product::convertPrice(0)); ?></p>
											<input type="hidden" id="d-val" value="<?php echo e(App\Models\Product::convertPrice(0)); ?>">
                                        </div>
                                        <!--<a href="#">Calculate shipping</a>-->

                                        <div class="cart_subtotal">
                                            <p>Total</p>
                                            <p class="main-total"><?php echo e(Session::has('cart') ? App\Models\Product::convertPrice($mainTotal) : '0.00'); ?></p>
                                        </div>
                                        <div class="checkout_btn">
                                            <a href="<?php echo e(route('front.checkout')); ?>">Proceed to Checkout</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
					<?php endif; ?>
                    <!--coupon code area end-->
                
            </div>
        </div>
        <!--shopping cart area end -->

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.vishruthi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vishruthijewelem/public_html/project/resources/views/front/cart.blade.php ENDPATH**/ ?>