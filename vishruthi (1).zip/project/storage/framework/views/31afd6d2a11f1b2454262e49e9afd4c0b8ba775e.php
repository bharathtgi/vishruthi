<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/front/vishruthi/css/order-page.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <!--breadcrumbs area start-->
        <div class="breadcrumbs_area other_bread">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb_content">
                            <ul>
                                <li><a href="<?php echo e(route('front.index')); ?>">home</a></li>
                                <li>/</li>
                                <li>orders</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--breadcrumbs area end-->

        <!-- my account start  -->
        <section class="main_content_area">
            <div class="container">
                <div class="account_dashboard">
                    <div class="row">
                        <?php echo $__env->make('includes.user-dashboard-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="col-sm-12 col-md-9 col-lg-9">
                            <div class="order-detail">
                                <!-- Tab panes -->
                                <div class="order">
                                    <h2>Order Details</h2>
                                    <div class="order-id">
                                        <h3>Order# <?php echo e($order->order_number); ?> [<?php echo e($order->status); ?>]</h3>
                                        <div class="ordered-details row">
                                            <div class="col-md-6">
												<ul>
													<li><span>Order Date</span>: <?php echo e(date('d-M-Y',strtotime($order->created_at))); ?></li>
													<li><span>Payment Status</span>: 
														<?php if($order->payment_status == 'Pending'): ?>
															Pending
														<?php else: ?>
															Paid
														<?php endif; ?>
													</li>
													<li><span>Paid Amount</span>: <?php echo e($order->currency_sign); ?><?php echo e(round($order->pay_amount * $order->currency_value , 2)); ?></li>
												</ul>
											</div>
											<div class="col-md-6">
												<ul>
													
													<li><span>Payment Method</span>: <?php echo e($order->method); ?></li>
													<li><span>Razorpay Transaction ID</span>: <?php echo e($order->txnid); ?></li>
												</ul>											
											</div>
                                        </div>
                                    </div>

                                    <div class="order-id">
                                        <h3>Shipping /  Billing Details</h3>
                                        <div class="ordered-details row">
                                            <div class="col-md-6">
												<ul>
													<li><span>Name</span>: <?php echo e($order->shipping_name == null ? $order->customer_name : $order->shipping_name); ?></li>
													<li><span>Email</span>: <?php echo e($order->shipping_email == null ? $order->customer_email : $order->shipping_email); ?></li>
													<li><span>Phone</span>: <?php echo e($order->shipping_phone == null ? $order->customer_phone : $order->shipping_phone); ?></li>
													<li style="line-height: 20px;"><span>Address</span>: 
														<?php echo e($order->shipping_address == null ? $order->customer_address : $order->shipping_address); ?><br/>
														<?php echo e($order->shipping_city == null ? $order->customer_city : $order->shipping_city); ?>-<?php echo e($order->shipping_zip == null ? $order->customer_zip : $order->shipping_zip); ?>

													</li>
												</ul>
											</div>
											<div class="col-md-6">
												<ul>
													<li><span>Name</span>: <?php echo e($order->customer_name); ?></li>
													<li><span>Email</span>: <?php echo e($order->customer_email); ?></li>
													<li><span>Phone</span>: <?php echo e($order->customer_phone); ?></li>
													<li style="line-height: 20px;"><span>Address</span>: No.12 New Colony, Chrompet qwqwqw-12121<?php echo e($order->customer_address); ?><br/>
														<?php echo e($order->customer_city); ?>-<?php echo e($order->customer_zip); ?>

													</li>
													
												</ul>											
											</div>
											<?php if($order->order_note != null): ?>
											<ul>
												<li><span>Order Note</span>: <?php echo e($order->order_note); ?></li>
											</ul>
											<?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="order-table">
                                        <h5>Ordered Products</h5>
                                        <div class="table-responsive">
                                            <table class="table table-bordered veiw-details-table">
												<thead>
													<tr>
														<th width="45%">Name</th>
														<th width="25%">Details</th>
														<th>Price</th>
														<th>Total</th>
													</tr>
												</thead>
												<?php 
												$subtotal = 0; 
												?>                                                
												<tbody>
													<?php $__currentLoopData = $cart['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<tr>
														<td><?php echo e($product['item']['name']); ?></td>
														<td>
															<?php echo e($langg->lang311); ?>: <?php echo e($product['qty']); ?>

															<?php if(!empty($product['chaintype'])): ?>
																<br/>Chain Type: <?php echo e($product['chaintype']); ?>

															<?php endif; ?>
															
															<?php if(!empty($product['banglesize'])): ?>
																<br/>Bangle Size: <?php echo e($product['banglesize']); ?>

															<?php endif; ?>
														</td>
														<td><?php echo e($order->currency_sign); ?><?php echo e(round($product['item_price'] * $order->currency_value,2)); ?></td>
														<td><?php echo e($order->currency_sign); ?><?php echo e(number_format((float)($product['price'] * $order->currency_value), 2, '.', '')); ?></td>
														<?php 
														$subtotal += round($product['price'] * $order->currency_value, 2);
														?>														
													</tr>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<tr >
														<td colspan="3" class="right">Sub Total</td>
														<td ><?php echo e($order->currency_sign); ?><?php echo e(number_format((float)($subtotal), 2, '.', '')); ?></td>
													</tr>
													<?php if(($order->tax_amount != '') && ($order->tax_amount != NULL) && ($order->tax_amount != 0)): ?>
													<tr >
														<td colspan="3" class="right">Tax</td>
														<td ><?php echo e($order->currency_sign); ?><?php echo e(number_format((float)($order->tax_amount), 2, '.', '')); ?></td>
													</tr>
													<?php endif; ?>
													<?php if(($order->coupon_discount != '') && ($order->coupon_discount != NULL) && ($order->coupon_discount != 0)): ?>
													<tr >
														<td colspan="3" class="right">Coupon Discount</td>
														<td ><?php echo e($order->currency_sign); ?><?php echo e(number_format((float)($order->coupon_discount), 2, '.', '')); ?></td>
													</tr>
													<?php endif; ?>													
													<tr>
														<td colspan="3" class="right">Total</td>
														<td ><?php echo e($order->currency_sign); ?><?php echo e(number_format((float)($order->pay_amount * $order->currency_value) , 2, '.', '')); ?></td>
													</tr>
												</tbody>
											</table>
											<div class="row">
                                                <div class="col-md-12">
                                                    <div class="total"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="edit-account-info-div">
                                        <div class="form-group">
                                            <a class="back-btn" href="<?php echo e(route('user-orders')); ?>">Back</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- my account end   -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.vishruthi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vishruthijewelem/public_html/project/resources/views/user/order/details.blade.php ENDPATH**/ ?>