
<?php $__env->startSection('content'); ?>

<!-- Breadcrumb Area Start -->
<!-- Breadcrumb Area End -->

    <div class="error_section">
        <div class="container">   
            <div class="row">
                <div class="col-12">
                    <div class="error_form">
                        <h1>404</h1>
                        <h2>Opps! PAGE NOT BE FOUND</h2>
                        <p>Sorry but the page you are looking for does not exist, have been<br> removed, name changed or is temporarily unavailable.</p>
                        <form action="#">
                            <input placeholder="Search..." type="text">
                            <button type="submit"><i class="ion-ios-search-strong"></i></button>
                        </form>
                        <a href="<?php echo e(route('front.index')); ?>">Back to home page</a>
                    </div>
                </div>
            </div>
        </div>    
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.vishruthi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vishruthijewelem/public_html/project/resources/views/errors/404.blade.php ENDPATH**/ ?>