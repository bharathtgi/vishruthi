<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<?php if(isset($page->meta_tag) && isset($page->meta_description)): ?>
        <meta name="keywords" content="<?php echo e($page->meta_tag); ?>">
        <meta name="description" content="<?php echo e($page->meta_description); ?>">
		<title><?php echo e($gs->title); ?></title>
	<?php elseif(isset($blog->meta_tag) && isset($blog->meta_description)): ?>
        <meta name="keywords" content="<?php echo e($blog->meta_tag); ?>">
        <meta name="description" content="<?php echo e($blog->meta_description); ?>">
		<title><?php echo e($gs->title); ?></title>
    <?php elseif(isset($productt)): ?>
		<meta name="keywords" content="<?php echo e(!empty($productt->meta_tag) ? implode(',', $productt->meta_tag ): ''); ?>">
		<meta name="description" content="<?php echo e($productt->meta_description != null ? $productt->meta_description : strip_tags($productt->description)); ?>">
	    <meta property="og:title" content="<?php echo e($productt->name); ?>" />
	    <meta property="og:description" content="<?php echo e($productt->meta_description != null ? $productt->meta_description : strip_tags($productt->description)); ?>" />
	    <meta property="og:image" content="<?php echo e(asset('assets/images/thumbnails/'.$productt->thumbnail)); ?>" />
	    <meta name="author" content="GeniusOcean">
    	<title><?php echo e(substr($productt->name, 0,11)."-"); ?><?php echo e($gs->title); ?></title>
    <?php else: ?>
	    <meta name="keywords" content="<?php echo e($seo->meta_keys); ?>">
	    <meta name="author" content="GeniusOcean">
		<title><?php echo e($gs->title); ?></title>
    <?php endif; ?>		
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/front/vishruthi/img/fav.png')); ?>">

    <!-- CSS 
    ========================= -->

    <!-- Plugins CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/front/vishruthi/css/plugins.css')); ?>">
    <!-- Main Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/front/vishruthi/css/style.css')); ?>">
	<!-- Theme CSS START -->
	<link rel="stylesheet" href="<?php echo e(asset('assets/front/css/toastr.css')); ?>" />
	<?php if( (Route::currentRouteName() == 'user-orders') ): ?>
	<!--<link rel="stylesheet" href="<?php echo e(asset('assets/front/css/all.css')); ?>">-->
	<?php endif; ?>	
	<!-- Theme CSS END -->
	<?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
    <!--Offcanvas menu area start-->
    <div class="off_canvars_overlay">
    </div>
    <div class="offcanvas_menu">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="col-lg-4 col-md-12">
                        <div class="logo">
                            <a href="<?php echo e(route('front.index')); ?>"><img src="<?php echo e(asset('assets/images/'.$gs->logo)); ?>" alt=""></a>
                        </div>
                    </div>
                    <div class="canvas_open">
                        <a href="javascript:void(0)"><i class="ion-navicon"></i></a>
                    </div>
                    <div class="offcanvas_menu_wrapper">
                        <div class="canvas_close">
                            <a href="javascript:void(0)"><i class="ion-android-close"></i></a>
                        </div>
                        <div id="menu" class="text-left ">
                            <ul class="offcanvas_main_menu">
                                <li class="menu-item-has-children active">
                                    <a href="<?php echo e(route('front.index')); ?>">Home</a>
                                </li>
								<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="menu-item-has-children">
                                    <a href="<?php echo e(route('front.category', [$data->slug])); ?>"><?php echo e($data->name); ?></a>
                                    <ul class="sub-menu">
										<?php $subcategories =  App\Models\Subcategory::where('category_id','=',$data->id)->where('status','=','1')->get();
										if (!empty($subcategories)) {
										foreach($subcategories as $subcategory){ ?>
											<li><a href="<?php echo e(route('front.category', [$data->slug, $subcategory->slug])); ?>"><?php echo e($subcategory->name); ?></a></li>
										<?php } } ?>
									</ul>
                                </li>								
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li class="menu-item-has-children">
                                    <a href="#">my account</a>
                                </li>
                                <li class="menu-item-has-children">
                                    <a href="#">About Us</a>
                                </li>
                                <li class="menu-item-has-children">
                                    <a href="#"> Contact Us</a>
                                </li>
                            </ul>
                        </div>
                        <div class="offcanvas_footer">
                            <span><a href="#"><i class="fa fa-envelope-o"></i> info@yourdomain.com</a></span>
                            <ul>
                                <li class="facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li class="twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li class="pinterest"><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
                                <li class="google-plus"><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                <li class="linkedin"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Offcanvas menu area end-->

    <!--header area start-->
    <header class="header_area">
        <!--header top start-->
        <div class="header_top">
            <div class="container">
                <div class="row align-items-center">
                    <!--<div class="col-lg-4 col-md-12">
                        <div class="welcome_text">
                            <ul>
                                <li><span>Delivery:</span> Delivery mab be delayed due to COVID-19</li>
                            </ul>
                        </div>
                    </div>-->
                    <div class="col-lg-4 col-md-12">
                        <div class="logo">
                            <a href="<?php echo e(route('front.index')); ?>"><img src="<?php echo e(asset('assets/images/'.$gs->logo)); ?>" alt=""></a>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-12 text-center">
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <div class="cart_area">
                            <?php if(Auth::guard('web')->check()): ?>
							<div class="wish cart_link">
                                <a href="<?php echo e(route('user-wishlists')); ?>"><i class="fa fa-heart-o"></i></a>
                                <span class="cart-quantity" id="wishlist-count"><?php echo e(Auth::user()->wishlistCount()); ?></span>
                            </div>
							<?php else: ?>
							<div class="wish cart_link">
                                <a href="javascript:;"><i class="fa fa-heart-o"></i></a>
                                <span class="cart-quantity" id="wishlist-count">0</span>
                            </div>							
							<?php endif; ?>
                            <div class="cart_link wish">
                                <a href="#"><i class="fa fa-shopping-basket"></i></a>
                                <span class="cart-quantity" id="cart-count"><?php echo e(Session::has('cart') ? count(Session::get('cart')->items) : '0'); ?></span>
                                <!--mini cart-->
                                <div class="mini_cart" id="cart-items">
									<?php echo $__env->make('load.cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                                <!--mini cart end-->
                            </div>
                            <div class="wish cart_link track">
                                <a href="javascript:;" data-toggle="modal" data-target="#trackid" class="track-btn">Track Order</a>
                            </div>
                            <div class="top-header">
                                <div class="content">
                                    <div class="left-content">
                                        <div class="list">
                                            <ul>
                                                <li>
                                                    <div class="currency-selector">
                                                        <!--<span>₹</span>
														<span><?php echo e(Session::has('currency') ?   DB::table('currencies')->where('id','=',Session::get('currency'))->first()->sign   : DB::table('currencies')->where('is_default','=',1)->first()->sign); ?><span>-->
                                                        <select id="site_currency" name="currency" class="currency selectors nice" style="display: none;">
															<?php $__currentLoopData = DB::table('currencies')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																<option value="<?php echo e(route('front.currency',$currency->id)); ?>" rel="<?php echo e($currency->sign); ?>" <?php echo e(Session::has('currency') ? ( Session::get('currency') == $currency->id ? 'selected' : '' ) : ( $currency->is_default == 1 ? 'selected' : '')); ?> ><?php echo e($currency->name); ?></option>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        <div class="nice-select currency selectors nice" tabindex="0">
															<span class="current"><?php echo e(Session::has('currency') ?   DB::table('currencies')->where('id','=',Session::get('currency'))->first()->name   : DB::table('currencies')->where('is_default','=',1)->first()->name); ?></span>
                                                            <ul class="list">
                                                                <?php $__currentLoopData = DB::table('currencies')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																<li data-value="<?php echo e(route('front.currency',$currency->id)); ?>" class="currency option <?php echo e(Session::has('currency') ? ( Session::get('currency') == $currency->id ? 'selected' : '' ) : ( $currency->is_default == 1 ? 'selected' : '')); ?>"><?php echo e($currency->name); ?></li>
																<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="right-content">
                                        <div class="list">
                                            <ul>												<?php if(!Auth::guard('web')->check()): ?>
                                                <li class="login">                                                    <a href="<?php echo e(route('user.login')); ?>" class="sign-log">                                                        <div class="links">                                                            <span class="sign-in">Login</span> <span>|</span>                                                            <span class="join">Register</span>                                                        </div>                                                    </a>                                                </li>												<?php else: ?>													<li class="login">														<a href="<?php echo e(route('user-dashboard')); ?>" class="sign-log">															<div class="links">																<span class="sign-in"><?php echo e(Auth::user()->name); ?></span> 															</div>														</a>													</li>															<li class="login">														<a href="javascript:;" class="sign-log">															<div class="links">																<span>|</span>															</div>														</a>													</li>																							<li class="login">														<a href="<?php echo e(route('user-logout')); ?>" class="sign-log">															<div class="links">																<span class="sign-in">Logout</span> 															</div>														</a>													</li>																									<?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <!-- Main Wrapper Start -->
                    </div>
                </div>
            </div>
        </div>
        <!--header top start-->

        <!--header middel start-->

        <!--header middel end-->

        <!--header bottom satrt-->
        <div class="header_bottom sticky-header">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12">
                        <div class="header_static">
                            <div class="main_menu_inner">
                                <div class="main_menu">
                                    <nav>
                                        <ul>
                                            <li class="active"><a href="<?php echo e(route('front.index')); ?>">Home </a>
                                            </li>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li >
												<a href="<?php echo e(route('front.category', [$data->slug])); ?>"><?php echo e($data->name); ?> <i class="fa fa-angle-down"></i></a>
                                                <ul class="sub_menu pages">
													<?php $subcategories =  App\Models\Subcategory::where('category_id','=',$data->id)->where('status','=','1')->get();
													if (!empty($subcategories)) {
													foreach($subcategories as $subcategory){ ?>
														<li><a href="<?php echo e(route('front.category', [$data->slug, $subcategory->slug])); ?>"><?php echo e($subcategory->name); ?></a></li>
													<?php } } ?>
                                                </ul>
                                            </li >	
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--header bottom end-->
    </header>
    <!--header area end-->

	<?php echo $__env->yieldContent('content'); ?>

    <!--footer area start-->
    <footer class="footer_widgets other_widgets">
        <div class="footer_top">
            <div class="container">
                <div class="footer_top_inner">
                    <div class="row">
                        <div class="col-lg-4 col-md-6">
                            <div class="widgets_container contact_us">
                                <?php $contact = App\Models\Pagesetting::where('id','=','1')->first(); ?>
								<h3>Contact Us</h3>
                                <div class="footer_contact">
                                    <img src="<?php echo e(asset('assets/images/'.$gs->footer_logo)); ?>" alt="">
                                    <p><b>Address:</b> <?php echo $contact->street; ?></p>
                                    <p><b>Phone:</b> <a href="tel:<?php echo e($contact->phone); ?>"><?php echo e($contact->phone); ?></a> </p>
                                    <p><b>Landline:</b> <a href="tel:<?php echo e($contact->fax); ?>"><?php echo e($contact->fax); ?></a> </p>
                                    <p><b>Email:</b> <?php echo e($contact->email); ?></p>
                                    <ul>
                                        <?php if($socialsetting->f_status == 1): ?>
										<li><a href="<?php echo e($socialsetting->facebook); ?>" target="_blank" title="facebook"><i class="fa fa-facebook"></i></a></li>
                                        <?php endif; ?>
										<?php if($socialsetting->g_status == 1): ?>
										<li><a href="<?php echo e($socialsetting->gplus); ?>" target="_blank" title="facebook"><i class="fa fa-google-plus"></i></a></li>
										<?php endif; ?>
										<?php if($socialsetting->t_status == 1): ?>
										<li><a href="<?php echo e($socialsetting->twitter); ?>" target="_blank" title="facebook"><i class="fa fa-twitter"></i></a></li>
										<?php endif; ?>										
										<?php if($socialsetting->l_status == 1): ?>
										<li><a href="<?php echo e($socialsetting->linkedin); ?>" target="_blank" title="facebook"><i class="fa fa-instagram"></i></a></li>
										<?php endif; ?>
                                    </ul>

                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-6 col-sm-6 col-6">
                            <div class="widgets_container">
                                <h3>Information</h3>
                                <div class="footer_menu">
                                    <ul>
										<?php $__currentLoopData = DB::table('pages')->where('footer','=',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li><a href="<?php echo e(route('front.page',$data->slug)); ?>"><?php echo e($data->title); ?></a></li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-6 col-sm-6 col-6">
                            <div class="widgets_container">
                                <h3>Quick Links</h3>
                                <div class="footer_menu">
                                    <ul>
										<?php if(Auth::guard('web')->check()): ?>
										<li><a href="<?php echo e(route('user-dashboard')); ?>">My Account</a></li>
										<?php else: ?>
										<li><a href="<?php echo e(route('user.login')); ?>">Sign In</a></li>
										<?php endif; ?>
                                        <li><a href="<?php echo e(route('front.contact')); ?>">Contact Us</a></li>
                                        <?php if($gs->is_faq == 1): ?>
										<li><a href="<?php echo e(route('front.faq')); ?>">FAQ</a></li>
										<?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-6">
                            <div class="widgets_container newsletter">
                                <h3><?php echo e($gs->popup_title); ?></h3>
                                <div class="newleter-content">
                                    <p><?php echo e($gs->popup_text); ?></p>
                                    <div class="subscribe_form">
                                        <!-- mailchimp-alerts Start -->
                                        <div class="mailchimp-alerts text-centre">
                                            <div class="mailchimp-submitting"></div>
                                            <!-- mailchimp-submitting end -->
                                            <div class="mailchimp-success"></div>
                                            <!-- mailchimp-success end -->
                                            <div class="mailchimp-error"></div>
                                            <!-- mailchimp-error end -->
                                        </div>
                                        <!-- mailchimp-alerts end -->                                        
										<form action="<?php echo e(route('front.subscribe')); ?>" id="subscribeform" method="POST" class="mc-form footer-newsletter" >
                                            <?php echo e(csrf_field()); ?>

											<input id="email" type="email" name="email" autocomplete="off" placeholder="Enter you email address here..." />
                                            <button id="sub-btn" type="submit">Subscribe !</button>
                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer_bottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="copyright_area">
                            <p> &copy; <?php echo e(date('Y')); ?> <strong> Vishruthi Jewel Emporium </strong> Design: <a href="https://www.mindmade.in/" target="_blank">MindMade</a></p>
                        </div>
                    </div>
                    <!--<div class="col-lg-6 col-md-6">
                        <div class="footer_custom_links">
                            <ul>
                                <li><a href="javascript:;">Order History</a></li>
                                <li><a href="javascript:;">Wish List</a></li>
                                <li><a href="javascript:;">Newsletter</a></li>
                            </ul>
                        </div>
                    </div>-->
                </div>
            </div>
        </div>
            <div class="whatsapp_icon">
                <a href="https://api.whatsapp.com/send?phone=+919787155003" target="_blank"><img src="<?php echo e(asset('assets/front/vishruthi/img/icon/whatsapp-logo.svg')); ?>" alt="whatsapp-logo" width="42" height="42"></a>
            </div>
    </footer>
    <!--footer area end-->

    <!-- modal area start-->
    <div class="modal fade" id="quickview" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
				<div class="submit-loader">
					<img src="<?php echo e(asset('assets/images/'.$gs->loader)); ?>" alt="">
				</div>                
				<div class="modal_body quick-view-modal">
                    
				</div>
            </div>
        </div>
    </div>
    <!-- modal area start-->
    
    <!-- modal area start-->
    <div class="modal fade" id="trackid" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog  modal-lg" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h6 class="modal-title"> <b>Order Tracking</b> </h6>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">

                        <div class="order-tracking-content">
                            <form id="track-form" class="track-form">
                                <?php echo e(csrf_field()); ?>

                                <input type="text" id="track-code" placeholder="Get Tracking Code" required="">
                                <button type="submit" class="mybtn1">View Tracking</button>
                                <a href="#" data-toggle="modal" data-target="#order-tracking-modal"></a>
                            </form>
                        </div>

                        <div>
				            <div class="submit-loader d-none">
								<img src="<?php echo e(asset('assets/images/'.$gs->loader)); ?>" alt="">
							</div>
							<div id="track-order">

							</div>
                        </div>

            </div>
            </div>
        </div>
    </div>
    

    
    <!-- modal area start-->

    <!--<div class="newletter-popup" >
        <div id="boxes" class="newletter-container">
            <div id="dialog" class="window">
                <div id="popup2">
                    <span class="b-close"><span>close</span></span>
                </div>
                <div class="box">
                    <div class="newletter-title">
                        <h2>Newsletter</h2>
                    </div>
                    <div class="box-content newleter-content">
                        <label class="newletter-label">Enter your email address to subscribe our notification of our new post &amp; features by email.</label>
                        <div id="frm_subscribe">
                            <form name="subscribe" id="subscribe_popup">
                                <input type="text" value="" name="subscribe_pemail" id="subscribe_pemail" placeholder="Enter you email address here...">
                                <input type="hidden" value="" name="subscribe_pname" id="subscribe_pname">
                                <div id="notification"></div>
                                <a class="theme-btn-outlined" onclick="email_subscribepopup()"><span>Subscribe</span></a>
                            </form>
                            <div class="subscribe-bottom">
                                <input type="checkbox" id="newsletter_popup_dont_show_again">
                                <label for="newsletter_popup_dont_show_again">Don't show this popup again</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>-->


    <!-- JS
============================================ -->
	<script type="text/javascript">

	  var mainurl = "<?php echo e(url('/')); ?>";

	  var gs      = <?php echo json_encode(\App\Models\Generalsetting::first()->makeHidden(['stripe_key', 'stripe_secret', 'smtp_pass', 'instamojo_key', 'instamojo_token', 'paystack_key', 'paystack_email', 'paypal_business', 'paytm_merchant', 'paytm_secret', 'paytm_website', 'paytm_industry', 'paytm_mode', 'molly_key', 'razorpay_key', 'razorpay_secret'])); ?>;

	  var langg    = <?php echo json_encode($langg); ?>;

	</script>
    <!-- Plugins JS -->
    <script src="<?php echo e(asset('assets/front/vishruthi/js/plugins.js')); ?>"></script>
    <!-- Main JS -->
    <script src="<?php echo e(asset('assets/front/vishruthi/js/main.js')); ?>"></script>

	<!-- Theme Js START-->
	<script src="<?php echo e(asset('assets/front/js/jquery.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/js/vue.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/jquery-ui/jquery-ui.min.js')); ?>"></script>
	<!-- popper -->
	<script src="<?php echo e(asset('assets/front/js/popper.min.js')); ?>"></script>
	<!-- bootstrap -->
	<script src="<?php echo e(asset('assets/front/js/bootstrap.min.js')); ?>"></script>
	<!-- plugin js-->
	<script src="<?php echo e(asset('assets/front/js/plugin.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/js/xzoom.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/js/jquery.hammer.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/js/setup.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/js/toastr.js')); ?>"></script>
	<!-- main 
	<script src="<?php echo e(asset('assets/front/js/main.js')); ?>"></script>-->
	<!-- custom -->
	<script src="<?php echo e(asset('assets/front/js/custom.js')); ?>"></script>
	<!-- Theme Js END-->
	<script type="text/javascript">
		$("#trackid").on("hidden.bs.modal", function () { 
			$('#track-form').trigger("reset");
			$("#track-order").html('');
		});	
		$("#quickview").on("hidden.bs.modal", function () {
			$(".quick-view-modal").html('');
		});
	</script>
	<?php echo $__env->yieldContent('scripts'); ?>

</body>

</html><?php /**PATH /home/vishruthijewelem/public_html/project/resources/views/layouts/vishruthi.blade.php ENDPATH**/ ?>