<?php $__env->startSection('content'); ?>
        <!--breadcrumbs area start-->
        <div class="breadcrumbs_area other_bread">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb_content">
                            <ul>
                                <li><a href="<?php echo e(route('front.index')); ?>">home</a></li>
                                <li>/</li>
                                <li>checkout</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--breadcrumbs area end-->

        <!--Checkout page section-->
        <div class="Checkout_section" id="accordion">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <?php if(!Auth::guard('web')->check()): ?>
						<div class="user-actions">
                            <div id="checkout_login" class="collapse" data-parent="#accordion">
                                <div class="checkout_info signin-form">
                                    <p>If you have shopped with us before, please enter your details in the boxes below. If you are a new customer please proceed to the Billing & Shipping section.</p>
									<?php
									if (Cookie::get('vishruthi_user_email') !== null) {
										$prefilled_email = Cookie::get('vishruthi_user_email');
										$prefilled_password = Cookie::get('vishruthi_user_pass');
									} else {
										$prefilled_email = "";
										$prefilled_password = "";
									}
									?>							
									<?php echo $__env->make('includes.admin.form-login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                                    
									<form class="mloginform" action="<?php echo e(route('user.login.submit')); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

										<input type="hidden" name="redirect_to" id="redirect_to" value="checkout">
										<div class="row">
											<div class="form_group col-6">
												<label>Email <span>*</span></label>
												<input type="email" name="email" placeholder="<?php echo e($langg->lang173); ?>" required="" value="<?php echo $prefilled_email; ?>"  />
											</div>
											<div class="form_group col-6">
												<label>Password <span>*</span></label>
												<input type="password" class="Password" name="password" placeholder="<?php echo e($langg->lang174); ?>" required=""  value="<?php echo $prefilled_password; ?>" />
											</div>
										</div>
                                        <div class="form_group group_3">
                                            <button type="submit">Login</button>
                                            <label for="remember_box">
                                                <input name="remember" id="mrp" <?php echo e(old('remember') ? 'checked' : ''); ?> type="checkbox" />
                                                <span> Remember me </span>
                                            </label>
                                        </div>
										<input type="hidden" name="modal" value="1">
										<input class="mauthdata" type="hidden" value="<?php echo e($langg->lang177); ?>">										
                                        <a href="<?php echo e(route('user-forgot')); ?>">Lost your password?</a>
                                    </form>
                                </div>
                            </div>
                        </div>
						<?php endif; ?>
                        <div class="user-actions">
                            <div id="checkout_coupon" class="collapse" data-parent="#accordion">
                                <div class="checkout_info">
                                    <form id="check-coupon-form" >
                                        <input placeholder="Coupon code" type="text" id="code" required="" autocomplete="off" />
                                        <button type="submit">Apply coupon</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="checkout_form">
                    <form id="" action="<?php echo e(route('razorpay.submit')); ?>" method="POST" class="checkoutform">
						<?php echo $__env->make('includes.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<?php echo $__env->make('includes.form-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<?php echo e(csrf_field()); ?>					
						<div class="row">
							<input type="hidden" id="shipping-cost" name="shipping_cost" value="0">
							<input type="hidden" id="packing-cost" name="packing_cost" value="0">
							<input type="hidden" name="dp" value="<?php echo e($digital); ?>">
							<input type="hidden" name="tax" value="<?php echo e($gs->tax); ?>">
							<input type="hidden" name="totalQty" value="<?php echo e($totalQty); ?>">
							<input type="hidden" name="vendor_shipping_id" value="<?php echo e($vendor_shipping_id); ?>">
							<input type="hidden" name="vendor_packing_id" value="<?php echo e($vendor_packing_id); ?>">
							<?php if(Session::has('coupon_total')): ?>
								<input type="hidden" name="total" id="grandtotal" value="<?php echo e($totalPrice); ?>">
								<input type="hidden" id="tgrandtotal" value="<?php echo e($totalPrice); ?>">
							<?php elseif(Session::has('coupon_total1')): ?>
								<input type="hidden" name="total" id="grandtotal" value="<?php echo e(preg_replace("/[^0-9,.]/", "", Session::get('coupon_total1') )); ?>">
								<input type="hidden" id="tgrandtotal" value="<?php echo e(preg_replace("/[^0-9,.]/", "", Session::get('coupon_total1') )); ?>">
							<?php else: ?>
								<input type="hidden" name="total" id="grandtotal" value="<?php echo e(round($totalPrice * $curr->value,2)); ?>">
								<input type="hidden" id="tgrandtotal" value="<?php echo e(round($totalPrice * $curr->value,2)); ?>">
							<?php endif; ?>
							<input type="hidden" id="ttotal" value="<?php echo e(Session::has('cart') ? App\Models\Product::convertPrice(Session::get('cart')->totalPrice) : '0'); ?>">
							<input type="hidden" name="coupon_code" id="coupon_code" value="<?php echo e(Session::has('coupon_code') ? Session::get('coupon_code') : ''); ?>">
							<input type="hidden" name="coupon_discount" id="coupon_discount" value="<?php echo e(Session::has('coupon') ? Session::get('coupon') : ''); ?>">
							<input type="hidden" name="coupon_id" id="coupon_id" value="<?php echo e(Session::has('coupon') ? Session::get('coupon_id') : ''); ?>">
							<input type="hidden" name="user_id" id="user_id" value="<?php echo e(Auth::guard('web')->check() ? Auth::guard('web')->user()->id : ''); ?>">
							<input type="hidden" name="method" id="pay_method" value="Razorpay">
							<input type="hidden" name="tax_amount" id="tax_amount" value="<?php echo e($tax_amount); ?>">
							<div class="col-lg-6 col-md-6">
								<h3>Billing Details</h3>
								<div class="row">
									<select class="form-control" id="shipop" name="shipping" required="" style="display:none;">
										<option value="shipto"><?php echo e($langg->lang149); ?></option>
										<option value="pickup"><?php echo e($langg->lang150); ?></option>
									</select>									
									<div class="col-lg-6 mb-20">
										<label>Full Name <span>*</span></label>
										<input type="text" name="name" placeholder="<?php echo e($langg->lang152); ?>" required="" value="<?php echo e(Auth::guard('web')->check() ? Auth::guard('web')->user()->name : ''); ?>" />
									</div>
									<div class="col-lg-6 mb-20">
										<label>Phone Number <span>*</span></label>
										<input type="text" name="phone" placeholder="<?php echo e($langg->lang153); ?>" required="" value="<?php echo e(Auth::guard('web')->check() ? Auth::guard('web')->user()->phone : ''); ?>" />
									</div>
									<div class="col-12 mb-20">
										<label>Email</label>
										<input type="text" name="email"	placeholder="<?php echo e($langg->lang154); ?>" required="" value="<?php echo e(Auth::guard('web')->check() ? Auth::guard('web')->user()->email : ''); ?>" />
									</div>

									<div class="col-12 mb-20">
										<label>Street address <span>*</span></label>
										<input type="text" name="address" placeholder="<?php echo e($langg->lang155); ?>" required="" value="<?php echo e(Auth::guard('web')->check() ? Auth::guard('web')->user()->address : ''); ?>" />
									</div>
									<div class="col-12 mb-20">
										<label for="country">Country <span>*</span></label>
										<select class="niceselect_option" name="customer_country" required="">
											<?php echo $__env->make('includes.countries', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
										</select>
									</div>									
									<div class="col-6 mb-20">
										<label>Town / City <span>*</span></label>
										<input type="text" name="city" placeholder="<?php echo e($langg->lang158); ?>" required="" value="<?php echo e(Auth::guard('web')->check() ? Auth::guard('web')->user()->city : ''); ?>" />
									</div>
									<div class="col-6 mb-20">
										<label>Postal Code <span>*</span></label>
										<input type="text" name="zip" placeholder="<?php echo e($langg->lang159); ?>" required="" value="<?php echo e(Auth::guard('web')->check() ? Auth::guard('web')->user()->zip : ''); ?>" />
									</div>
									<!--<div class="col-12 mb-20">
										<input id="account" type="checkbox" data-target="createp_account" />
										<label for="account" data-toggle="collapse" data-target="#collapseOne" aria-controls="collapseOne">Create an account?</label>

										<div id="collapseOne" class="collapse one" data-parent="#accordion">
											<div class="card-body1">
												<label> Account password <span>*</span></label>
												<input placeholder="password" type="password" />
											</div>
										</div>
									</div>-->
									<div class="col-12 mb-20">
										<input id="ship-diff-address" type="checkbox" value="value1" data-target="createp_account" />
										<label class="righ_0" for="address" >Ship to a different address?</label>
										<div class="ship-diff-addres-area d-none" >
											<div class="row">
												<div class="col-lg-6 mb-20">
													<label><?php echo e($langg->lang152); ?> <span>*</span></label>
													<input type="text" name="shipping_name" id="shippingFull_name" placeholder="<?php echo e($langg->lang152); ?>" />
												</div>
												<div class="col-lg-6 mb-20">
													<label><?php echo e($langg->lang153); ?> <span>*</span></label>
													<input type="text" name="shipping_phone" id="shipingPhone_number" placeholder="<?php echo e($langg->lang153); ?>" />
												</div>
												<div class="col-12 mb-20">
													<div class="select_form_select">
														<label for="countru_name">country <span>*</span></label>
														<select class="niceselect_option" name="shipping_country">
															<?php echo $__env->make('includes.countries', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
														</select>
													</div>
												</div>
												<div class="col-12 mb-20">
													<label>Street address <span>*</span></label>
													<input placeholder="House number and street name" type="text" name="shipping_city"	id="shipping_city" placeholder="<?php echo e($langg->lang158); ?>" />
												</div>
												<div class="col-lg-6 mb-20">
													<label><?php echo e($langg->lang158); ?><span>*</span></label>
													<input type="text" name="shipping_city" id="shipping_city" placeholder="<?php echo e($langg->lang158); ?>" />
												</div>
												<div class="col-lg-6">
													<label> <?php echo e($langg->lang159); ?> <span>*</span></label>
													<input type="text" name="shipping_zip"	id="shippingPostal_code" placeholder="<?php echo e($langg->lang159); ?>" />
												</div>
											</div>
										</div>
									</div>
									<div class="col-12">
										<div class="order-notes">
											<label for="order_note">Order Notes</label>
											<textarea id="order_note" placeholder="Notes about your order, e.g. special notes for delivery." name="order_notes" ></textarea>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6">
								<h3>Your order</h3>
								<div class="order_table table-responsive">
									<table>
										<thead>
											<tr>
												<th>Product</th>
												<th>Total</th>
											</tr>
										</thead>
										<tbody>
											<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td><?php echo e($product['item']['name']); ?> <strong> × <?php echo e($product['qty']); ?></strong>
													<?php if(!empty($product['chaintype'])): ?>
														<br/><b>Chain Type</b> : <?php echo e($product['chaintype']); ?>

													<?php endif; ?>
													<?php if(!empty($product['banglesize'])): ?>
														<br/><b>Bangle Size</b> : <?php echo e($product['banglesize']); ?>

													<?php endif; ?>													
												</td>
												<td><?php echo e($curr->sign); ?><?php echo e(number_format((float)($product['price']), 2, '.', '')); ?></td>
											</tr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</tbody>
										<tfoot>
											<tr>
												<th>Cart Subtotal</th>
												<td class="cart-total"><?php echo e(Session::has('cart') ? $curr->sign.number_format((float)(Session::get('cart')->totalPrice), 2, '.', '') : '0.00'); ?></td>
											</tr>
											<?php if($gs->tax != 0): ?>
											<tr>
												<th><?php echo e($langg->lang144); ?> (<?php echo e($gs->tax); ?>%)</th>
												<td><?php echo e($curr->sign); ?><?php echo e($tax_amount); ?></td>
											</tr>											
											<?php endif; ?>
											
											<tr id="coupon_tr" <?php if(Session::has('coupon')) { ?>   <?php } else { ?> style="display:none;" <?php } ?> >
												<th>Coupon Discount</th>
												<td id="coupon_discount_price">
												<?php echo e($curr->sign.number_format((float)(Session::get('coupon')), 2, '.', '')); ?>

												</td>
											</tr>
											
											<tr class="order_total">
												<th>Order Total</th>
												<td><strong id="final-cost"><?php echo e($curr->sign); ?><?php echo e($totalPrice); ?></strong></td>
											</tr>
										</tfoot>
									</table>
								</div>
								<div class="payment_method">
                                    <?php if($gs->cod_check == 1): ?>
									<div class="panel-default" style="display:none;">
										<input id="payment_cod" name="check_method" type="radio" data-target="createp_account" class="payment_method" />
										<label for="payment_cod" ><?php echo e($langg->lang762); ?> </label>
										<div id="collapsedefult" class="collapse one" data-parent="#accordion">
											<div class="card-body1">
												<?php if($gs->cod_text != null): ?>
												<p><?php echo e($gs->cod_text); ?></p>
												<?php endif; ?>
											</div>
										</div>
									</div>
									<?php endif; ?>
									<?php if($gs->is_razorpay == 1): ?>
									<div class="panel-default">
										<input id="payment_razorpay" name="check_method" type="radio" data-target="createp_account" class="payment_method" checked />
										<label for="payment_razorpay" ><?php echo e($langg->razorpay); ?> </label>
										<div id="collapsedefult" class="collapse one" data-parent="#accordion">
											<div class="card-body1">
												<?php if($gs->razorpay_text != null): ?>
												<p><?php echo e($gs->razorpay_text); ?></p>
												<?php endif; ?>
											</div>
										</div>
									</div>									
									<?php endif; ?>									
									<div class="order_button">
										<button type="submit">Proceed to Pay</button>
									</div>
								</div>
							</div>
						</div>
					</form>
                </div>
            </div>
        </div>
        <!--Checkout page section end-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript">
		var pos = <?php echo e($gs->currency_format); ?>;
		$("#ship-diff-address").on( "change", function() {
            if(this.checked){
				$('.ship-diff-addres-area').removeClass('d-none');  
				$('.ship-diff-addres-area input, .ship-diff-addres-area select').prop('required',true); 
            } else {
				$('.ship-diff-addres-area').addClass('d-none');  
				$('.ship-diff-addres-area input, .ship-diff-addres-area select').prop('required',false);  
            }
        });
		$("#check-coupon-form").on('submit', function () {
			var val = $("#code").val();
			var total = $("#ttotal").val();
			var ship = 0;
			$.ajax({
				type: "GET",
				url:mainurl+"/carts/coupon/check",
				data:{code:val, total:total, shipping_cost:ship},
				success:function(data){
					if(data == 0)	{
						toastr.error(langg.no_coupon);
						$("#code").val("");
					} else if(data == 2)	{
						toastr.error(langg.already_coupon);
						$("#code").val("");
					}	else	{
						//$("#check-coupon-form").toggle();
						$("#code").val("");
						//$(".discount-bar").removeClass('d-none');
						if(pos == 0){
							//$('#final-cost').html('<?php echo e($curr->sign); ?>'+data[0]);
							var coupon_price = Math.round(data[2]).toFixed(2);
							$('#coupon_discount_price').html('<?php echo e($curr->sign); ?>'+ data[2]);
							$('#coupon_tr').css('display','contents');
						}	else{
							//$('#final-cost').html(data[0]+'<?php echo e($curr->sign); ?>');
							var coupon_price = Math.round(data[2]).toFixed(2);
							$('#coupon_discount_price').html(data[2] +'<?php echo e($curr->sign); ?>');
							$('#coupon_tr').css('display','contents');
						}
						$('#grandtotal').val(data[0]);
						$('#tgrandtotal').val(data[0]);
						$('#coupon_code').val(data[1]);
						$('#coupon_discount').val(data[2]);
						$('#coupon_id').val(data[3]);
/* 						if(data[4] != 0){
							$('.dpercent').html('('+data[4]+')');
						}	else{
							$('.dpercent').html('');									
						} */
						//var ttotal = parseFloat($('#grandtotal').val()) + parseFloat(mship) + parseFloat(mpack);
						var ttotal = parseFloat($('#grandtotal').val())
						ttotal = parseFloat(ttotal);
						if(ttotal % 1 != 0)  {
							ttotal = ttotal.toFixed(2);
						}
						if(pos == 0){
							Math.round(ttotal).toFixed(2);
							$('#final-cost').html('<?php echo e($curr->sign); ?>'+ttotal)
						} else{
							Math.round(ttotal).toFixed(2);
							$('#final-cost').html(ttotal+'<?php echo e($curr->sign); ?>')
						}	
						toastr.success(langg.coupon_found);
						$("#code").val("");
					}
				}
			}); 
			return false;
		});		
	</script>
<?php $__env->stopSection(); ?>	
<?php echo $__env->make('layouts.vishruthi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vishruthijewelem/public_html/project/resources/views/front/checkout.blade.php ENDPATH**/ ?>